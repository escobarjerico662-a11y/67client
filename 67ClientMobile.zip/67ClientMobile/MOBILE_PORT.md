# 67Client – mobile port notes

Target: Fabric 1.21.11 on Android via PojavLauncher / Zalith / Amethyst / FCL.

## What changed
- `mobile/MobileSupport` – detects Android launchers; picks the renderer.
- `render/nanovg/VanillaRenderer` – DrawContext-based 2D backend with the same API as `NVGRenderer`.
  `NVGRenderer` now delegates every call to it when `MobileSupport.useFallback()` is true
  (all HUD / ClickGUI code is untouched).
- `render/OverlayRenderer` – skips the raw GL33 path in fallback mode; new `renderFallbackHud/Screen`;
  UI scale on mobile = framebuffer height / 600 (was /1080) so touch targets are bigger.
- `mobile/MobileHooks` – HUD callback, ClickGUI drawing, a "67" button on Title/Pause screens,
  `.gui` chat command.
- `gui/ClickGuiScreen` – on mobile, drag up/down on the right edge of a panel body to scroll it.
- `NVGImages`, `NVGIcons`, `SpotifyHud` – guarded so no NanoVG calls happen without a context.
- Removed `META-INF/67c.txt` (a per-user license file with a Discord ID) from this copy.

## JVM args (launcher "Java arguments")
- `-Dsixseven.mobile=true|false`      force mobile mode
- `-Dsixseven.renderer=vanilla|nanovg` force renderer
- `-Dsixseven.uiheight=600`           smaller = bigger UI

## Known limitations (fallback renderer)
- No images/item icons/skin heads/SVG category icons, no glows, no motion blur.
- Rounded corners are stair-stepped; horizontal gradients are strips.
- World-space ESP/render modules depend on your launcher's GL renderer (Zink/ANGLE/MobileGlues
  work best); not changed here.
- Keyboard-only keybinds need Pojav on-screen buttons mapped to the keys.

## NOT compiled
Built without Gradle/Minecraft deps. New files were only type-checked against stubs.
Run `./gradlew build` and fix any Yarn API mismatches (DrawContext matrix stack methods,
HudRenderCallback / ScreenEvents.afterRender signatures).
