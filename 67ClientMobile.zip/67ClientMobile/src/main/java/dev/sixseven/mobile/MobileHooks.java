package dev.sixseven.mobile;

import dev.sixseven.SixSevenClient;
import dev.sixseven.gui.ClickGuiScreen;
import dev.sixseven.render.NvgDrawable;
import dev.sixseven.render.OverlayRenderer;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/**
 * Hooks that make the client usable without a keyboard / desktop GL:
 *  - draws the HUD and ClickGUI through the vanilla renderer when NanoVG can't run;
 *  - adds a "67" button on the title + pause screens (tap to open the ClickGUI);
 *  - adds a ".gui" chat command (type it in chat to open the ClickGUI).
 */
public final class MobileHooks {
   private MobileHooks() {
   }

   public static void register() {
      HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
         if (MobileSupport.useFallback()) {
            OverlayRenderer.renderFallbackHud(drawContext);
         }
      });

      ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
         if (MobileSupport.useFallback() && screen instanceof NvgDrawable) {
            ScreenEvents.afterRender(screen).register((s, drawContext, mouseX, mouseY, tickDelta) -> OverlayRenderer.renderFallbackScreen(drawContext, s));
         }

         if (MobileSupport.isMobile() && (screen instanceof TitleScreen || screen instanceof GameMenuScreen)) {
            Screens.getButtons(screen).add(
               ButtonWidget.builder(Text.literal("67"), button -> MinecraftClient.getInstance().setScreen(new ClickGuiScreen()))
                  .dimensions(scaledWidth - 44, 4, 40, 20)
                  .build()
            );
         }
      });

      ClientSendMessageEvents.ALLOW_CHAT.register(message -> {
         String m = message.trim();
         if (m.equalsIgnoreCase(".gui") || m.equalsIgnoreCase(".67")) {
            MinecraftClient mc = MinecraftClient.getInstance();
            mc.execute(() -> mc.setScreen(new ClickGuiScreen()));
            return false;
         }
         return true;
      });

      SixSevenClient.LOGGER.info("[mobile] mobile={} vanillaRenderer={}", MobileSupport.isMobile(), MobileSupport.useFallback());
   }
}
