package dev.sixseven.mobile;

import java.util.Locale;

/**
 * Detects Android launchers (PojavLauncher, Zalith, Amethyst, FCL, ...) and decides whether the
 * client should use the vanilla DrawContext renderer instead of NanoVG (which needs desktop GL 3.3).
 *
 * Overrides (JVM args):
 *   -Dsixseven.mobile=true|false      force mobile behaviour on/off
 *   -Dsixseven.renderer=vanilla|nanovg force the 2D renderer
 *   -Dsixseven.uiheight=600           target UI height (smaller = bigger UI) on mobile
 */
public final class MobileSupport {
   private static Boolean mobile;
   private static Boolean fallback;

   private MobileSupport() {
   }

   public static boolean isMobile() {
      if (mobile == null) {
         mobile = detectMobile();
      }
      return mobile;
   }

   public static boolean useFallback() {
      if (fallback != null) {
         return fallback;
      }
      String forced = System.getProperty("sixseven.renderer", "").toLowerCase(Locale.ROOT);
      if (forced.equals("vanilla")) {
         return fallback = true;
      }
      if (forced.equals("nanovg")) {
         return fallback = false;
      }
      if (isMobile()) {
         return fallback = true;
      }
      try {
         // Desktop with an old / limited GL driver: fall back instead of crashing NanoVG.
         boolean gl33 = org.lwjgl.opengl.GL.getCapabilities().OpenGL33;
         return fallback = !gl33;
      } catch (Throwable t) {
         return false; // no context yet; ask again later, don't cache
      }
   }

   public static float targetUiHeight() {
      try {
         return Math.max(240.0F, Float.parseFloat(System.getProperty("sixseven.uiheight", "600")));
      } catch (NumberFormatException e) {
         return 600.0F;
      }
   }

   private static boolean detectMobile() {
      String forced = System.getProperty("sixseven.mobile");
      if (forced != null) {
         return Boolean.parseBoolean(forced);
      }
      String[] envKeys = {"POJAV_RENDERER", "POJAV_NATIVEDIR", "POJAV_ENVIRON", "FCL_NATIVEDIR", "FCL_RENDERER", "ZALITH_RENDERER"};
      for (String key : envKeys) {
         if (System.getenv(key) != null) {
            return true;
         }
      }
      String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
      String vendor = System.getProperty("java.vendor", "").toLowerCase(Locale.ROOT);
      String home = System.getProperty("user.home", "");
      String libs = System.getProperty("org.lwjgl.librarypath", "").toLowerCase(Locale.ROOT);
      return os.contains("android")
         || vendor.contains("android")
         || home.startsWith("/data/")
         || libs.contains("pojav")
         || libs.contains("/data/user/")
         || libs.contains("/data/data/");
   }
}
