package dev.sixseven.render.nanovg;

import java.util.ArrayDeque;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/**
 * Drop-in 2D backend for {@link NVGRenderer} built on vanilla DrawContext, for devices where
 * NanoVG / desktop OpenGL 3.3 is unavailable (Android launchers). Same method names and units as
 * NVGRenderer; the caller works in "pixel" units after beginFrame, exactly like with NanoVG.
 * Fidelity trade-offs: rounded corners are stair-stepped, glows/images are skipped, horizontal
 * gradients are drawn as strips.
 */
public final class VanillaRenderer {
   private static final float TEXT_UNIT = 10.0F; // NVG font px -> vanilla font scale
   private DrawContext dc;
   private float alpha = 1.0F;
   private int scissorDepth = 0;
   private int matrixDepth = 0;
   private final ArrayDeque<float[]> frames = new ArrayDeque<>();

   public void bind(DrawContext context) {
      this.dc = context;
   }

   private TextRenderer tr() {
      return MinecraftClient.getInstance().textRenderer;
   }

   private int col(int argb) {
      int a = (int)(((argb >>> 24) & 0xFF) * this.alpha);
      return a << 24 | (argb & 0xFFFFFF);
   }

   private static boolean invisible(int argb) {
      return (argb >>> 24) == 0;
   }

   private static int lerp(int a, int b, float t) {
      int aa = (int)((a >>> 24) + ((b >>> 24) - (a >>> 24)) * t);
      int ar = (int)(((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
      int ag = (int)(((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
      int ab = (int)((a & 255) + ((b & 255) - (a & 255)) * t);
      return aa << 24 | ar << 16 | ag << 8 | ab;
   }

   // ---- frame / state ----

   public boolean hasFont() {
      return true;
   }

   public void setFontMode(String mode) {
   }

   public void beginFrame(float width, float height, float pixelRatio) {
      this.alpha = 1.0F;
      this.frames.clear();
      this.scissorDepth = 0;
      this.matrixDepth = 0;
      if (this.dc != null) {
         double gs = Math.max(1.0, MinecraftClient.getInstance().getWindow().getScaleFactor());
         this.dc.getMatrices().pushMatrix();
         this.dc.getMatrices().scale((float)(1.0 / gs), (float)(1.0 / gs));
         this.matrixDepth = 1;
      }
   }

   public void endFrame() {
      if (this.dc == null) {
         return;
      }
      while (this.scissorDepth > 0) {
         this.dc.disableScissor();
         this.scissorDepth--;
      }
      while (this.matrixDepth > 0) {
         this.dc.getMatrices().popMatrix();
         this.matrixDepth--;
      }
      this.frames.clear();
   }

   public void save() {
      if (this.dc == null) {
         return;
      }
      this.frames.push(new float[]{this.alpha, this.scissorDepth});
      this.dc.getMatrices().pushMatrix();
      this.matrixDepth++;
   }

   public void restore() {
      if (this.dc == null || this.frames.isEmpty()) {
         return;
      }
      float[] f = this.frames.pop();
      this.alpha = f[0];
      while (this.scissorDepth > (int)f[1]) {
         this.dc.disableScissor();
         this.scissorDepth--;
      }
      this.dc.getMatrices().popMatrix();
      this.matrixDepth--;
   }

   public void scale(float s) {
      if (this.dc != null) {
         this.dc.getMatrices().scale(s, s);
      }
   }

   public void translate(float x, float y) {
      if (this.dc != null) {
         this.dc.getMatrices().translate(x, y);
      }
   }

   public void rotate(float radians) {
      if (this.dc != null) {
         this.dc.getMatrices().rotate(radians);
      }
   }

   public void alpha(float a) {
      this.alpha *= Math.max(0.0F, Math.min(1.0F, a));
   }

   public void scissor(float x, float y, float w, float h) {
      if (this.dc == null) {
         return;
      }
      int x1 = Math.round(x);
      int y1 = Math.round(y);
      this.dc.enableScissor(x1, y1, x1 + Math.max(0, Math.round(w)), y1 + Math.max(0, Math.round(h)));
      this.scissorDepth++;
   }

   // ---- primitives ----

   private void fillI(int x1, int y1, int x2, int y2, int argb) {
      if (x2 > x1 && y2 > y1 && !invisible(argb)) {
         this.dc.fill(x1, y1, x2, y2, argb);
      }
   }

   private void roundedFill(float x, float y, float w, float h, float radius, int argb) {
      int ix = Math.round(x);
      int iy = Math.round(y);
      int iw = Math.round(w);
      int ih = Math.round(h);
      if (iw <= 0 || ih <= 0 || invisible(argb)) {
         return;
      }
      int r = Math.min(Math.round(radius), Math.min(iw, ih) / 2);
      r = Math.min(r, 8);
      if (r <= 1) {
         this.fillI(ix, iy, ix + iw, iy + ih, argb);
         return;
      }
      for (int i = 0; i < r; i++) {
         double dy = r - i - 0.5;
         int inset = r - (int)Math.round(Math.sqrt(r * r - dy * dy));
         this.fillI(ix + inset, iy + i, ix + iw - inset, iy + i + 1, argb);
         this.fillI(ix + inset, iy + ih - 1 - i, ix + iw - inset, iy + ih - i, argb);
      }
      this.fillI(ix, iy + r, ix + iw, iy + ih - r, argb);
   }

   public void rect(float x, float y, float w, float h, float radius, int argb) {
      if (this.dc != null) {
         this.roundedFill(x, y, w, h, radius, this.col(argb));
      }
   }

   public void rectGradient(float x, float y, float w, float h, float radius, int from, int to, boolean vertical) {
      if (this.dc == null) {
         return;
      }
      int ix = Math.round(x);
      int iy = Math.round(y);
      int iw = Math.round(w);
      int ih = Math.round(h);
      if (iw <= 0 || ih <= 0) {
         return;
      }
      int a = this.col(from);
      int b = this.col(to);
      if (vertical) {
         this.dc.fillGradient(ix, iy, ix + iw, iy + ih, a, b);
      } else {
         int n = Math.max(1, Math.min(iw, 48));
         for (int i = 0; i < n; i++) {
            int x0 = ix + iw * i / n;
            int x1 = ix + iw * (i + 1) / n;
            this.fillI(x0, iy, x1, iy + ih, lerp(a, b, (i + 0.5F) / n));
         }
      }
   }

   public void rectVaryingGradient(float x, float y, float w, float h, float rtl, float rtr, float rbr, float rbl, int from, int to) {
      this.rectGradient(x, y, w, h, 0.0F, from, to, true);
   }

   public void rectOutline(float x, float y, float w, float h, float radius, float stroke, int argb) {
      if (this.dc == null) {
         return;
      }
      int c = this.col(argb);
      int ix = Math.round(x);
      int iy = Math.round(y);
      int iw = Math.round(w);
      int ih = Math.round(h);
      int s = Math.max(1, Math.round(stroke));
      this.fillI(ix, iy, ix + iw, iy + s, c);
      this.fillI(ix, iy + ih - s, ix + iw, iy + ih, c);
      this.fillI(ix, iy + s, ix + s, iy + ih - s, c);
      this.fillI(ix + iw - s, iy + s, ix + iw, iy + ih - s, c);
   }

   public void glow(float x, float y, float w, float h, float radius, float spread, int argb) {
   }

   public void circleGlow(float cx, float cy, float r, float spread, int argb) {
   }

   public void circle(float cx, float cy, float r, int argb) {
      if (this.dc == null) {
         return;
      }
      int c = this.col(argb);
      int ir = Math.max(1, Math.round(r));
      int icx = Math.round(cx);
      int icy = Math.round(cy);
      for (int dy = -ir; dy < ir; dy++) {
         double yy = dy + 0.5;
         int half = (int)Math.round(Math.sqrt(Math.max(0.0, (double)ir * ir - yy * yy)));
         this.fillI(icx - half, icy + dy, icx + half, icy + dy + 1, c);
      }
   }

   public void circleOutline(float cx, float cy, float r, float stroke, int argb) {
      if (this.dc == null) {
         return;
      }
      int c = this.col(argb);
      int icx = Math.round(cx);
      int icy = Math.round(cy);
      double ro = Math.max(1.0, r);
      double ri = Math.max(0.0, r - Math.max(1.0F, stroke));
      int ir = (int)Math.ceil(ro);
      for (int dy = -ir; dy < ir; dy++) {
         double yy = dy + 0.5;
         int ho = (int)Math.round(Math.sqrt(Math.max(0.0, ro * ro - yy * yy)));
         int hi = Math.abs(yy) < ri ? (int)Math.round(Math.sqrt(Math.max(0.0, ri * ri - yy * yy))) : 0;
         if (hi <= 0) {
            this.fillI(icx - ho, icy + dy, icx + ho, icy + dy + 1, c);
         } else {
            this.fillI(icx - ho, icy + dy, icx - hi, icy + dy + 1, c);
            this.fillI(icx + hi, icy + dy, icx + ho, icy + dy + 1, c);
         }
      }
   }

   public void line(float x1, float y1, float x2, float y2, float width, int argb) {
      if (this.dc == null) {
         return;
      }
      int c = this.col(argb);
      int w = Math.max(1, Math.round(width));
      float dx = x2 - x1;
      float dy = y2 - y1;
      int steps = (int)Math.ceil(Math.max(Math.abs(dx), Math.abs(dy)));
      if (steps <= 0) {
         this.fillI(Math.round(x1 - w / 2.0F), Math.round(y1 - w / 2.0F), Math.round(x1 - w / 2.0F) + w, Math.round(y1 - w / 2.0F) + w, c);
         return;
      }
      for (int i = 0; i <= steps; i++) {
         float t = (float)i / steps;
         int px = Math.round(x1 + dx * t - w / 2.0F);
         int py = Math.round(y1 + dy * t - w / 2.0F);
         this.fillI(px, py, px + w, py + w, c);
      }
   }

   public void chevron(float cx, float cy, float size, float stroke, int argb, boolean pointDown) {
      if (pointDown) {
         this.line(cx - size, cy - size / 2.0F, cx, cy + size / 2.0F, stroke, argb);
         this.line(cx, cy + size / 2.0F, cx + size, cy - size / 2.0F, stroke, argb);
      } else {
         this.line(cx - size / 2.0F, cy - size, cx + size / 2.0F, cy, stroke, argb);
         this.line(cx + size / 2.0F, cy, cx - size / 2.0F, cy + size, stroke, argb);
      }
   }

   public void triangle(float x0, float y0, float x1, float y1, float x2, float y2, int argb) {
      if (this.dc == null) {
         return;
      }
      int c = this.col(argb);
      float[] xs = {x0, x1, x2};
      float[] ys = {y0, y1, y2};
      int top = (int)Math.floor(Math.min(y0, Math.min(y1, y2)));
      int bottom = (int)Math.ceil(Math.max(y0, Math.max(y1, y2)));
      for (int y = top; y < bottom; y++) {
         float yy = y + 0.5F;
         float minX = Float.MAX_VALUE;
         float maxX = -Float.MAX_VALUE;
         for (int i = 0; i < 3; i++) {
            int j = (i + 1) % 3;
            float ya = ys[i];
            float yb = ys[j];
            if ((yy >= Math.min(ya, yb)) && (yy <= Math.max(ya, yb)) && ya != yb) {
               float x = xs[i] + (yy - ya) * (xs[j] - xs[i]) / (yb - ya);
               minX = Math.min(minX, x);
               maxX = Math.max(maxX, x);
            }
         }
         if (maxX > minX) {
            this.fillI(Math.round(minX), y, Math.round(maxX), y + 1, c);
         }
      }
   }

   public void checkmark(float x, float y, float size, float stroke, int argb) {
      this.line(x, y + size * 0.5F, x + size * 0.38F, y + size * 0.9F, stroke, argb);
      this.line(x + size * 0.38F, y + size * 0.9F, x + size, y + size * 0.1F, stroke, argb);
   }

   public void cross(float x, float y, float size, float stroke, int argb) {
      this.line(x, y, x + size, y + size, stroke, argb);
      this.line(x + size, y, x, y + size, stroke, argb);
   }

   // ---- text (y is the vertical middle, like NVG_ALIGN_MIDDLE) ----

   public float text(String str, float x, float y, float size, int argb) {
      return this.text(str, x, y, size, argb, null);
   }

   public float text(String str, float x, float y, float size, int argb, String font) {
      if (this.dc == null || str == null || str.isEmpty()) {
         return 0.0F;
      }
      float k = size / TEXT_UNIT;
      int c = this.col(argb);
      if (!invisible(c)) {
         this.dc.getMatrices().pushMatrix();
         this.dc.getMatrices().translate(x, y);
         this.dc.getMatrices().scale(k, k);
         this.dc.drawText(this.tr(), str, 0, -4, c, false);
         this.dc.getMatrices().popMatrix();
      }
      return this.tr().getWidth(str) * k;
   }

   public float textGradient(String str, float x, float y, float size, int top, int bottom) {
      return this.text(str, x, y, size, lerp(top, bottom, 0.5F), null);
   }

   public void textGlow(String str, float x, float y, float size, int argb) {
      this.text(str, x, y, size, argb, null);
   }

   public float textTruncated(String str, float x, float y, float size, int argb, float maxWidth) {
      if (this.textWidth(str, size) <= maxWidth) {
         return this.text(str, x, y, size, argb, null);
      }
      String cut = str;
      while (cut.length() > 1 && this.textWidth(cut + "…", size) > maxWidth) {
         cut = cut.substring(0, cut.length() - 1);
      }
      return this.text(cut + "…", x, y, size, argb, null);
   }

   public float textWidth(String str, float size) {
      if (str == null || str.isEmpty()) {
         return 0.0F;
      }
      return this.tr().getWidth(str) * (size / TEXT_UNIT);
   }

   // ---- images: not supported by the vanilla backend ----

   public void imagePattern(int image, float patternX, float patternY, float patternW, float patternH, float x, float y, float w, float h, float alphaMul) {
   }

   public void image(int image, float x, float y, float w, float h, int tint) {
   }
}
