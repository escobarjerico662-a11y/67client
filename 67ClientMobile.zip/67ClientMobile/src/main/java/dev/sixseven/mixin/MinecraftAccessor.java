package dev.sixseven.mixin;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({MinecraftClient.class})
public interface MinecraftAccessor {
   @Accessor("field_1752")
   void sixsevenclient$setRightClickDelay(int var1);

   @Invoker("method_1536")
   boolean sixsevenclient$startAttack();

   @Invoker("method_1583")
   void sixsevenclient$startUseItem();
}
